
export const SliderData = [
    {
        image:'http://wallpup.com/wp-content/uploads/2013/03/Nike-Lebron-X-Wallpaper.jpg'
    },
    {
        image:'https://www.wallpaperup.com/uploads/wallpapers/2015/05/24/697382/f360e8817121d996697119dfa01bf903-700.jpg'
    },
    {
        image:'https://cdn.thecoolist.com/wp-content/uploads/2016/06/Adidas-Ad-Photo-The-Coolist.jpg'
    },
    {
        image:'http://images.solecollector.com/complex/image/upload/fl_lossy,q_auto/i8m595rhllwbvxg4astc.jpg'
    },
    {
        image:'http://images.solecollector.com/complex/image/upload/fl_lossy,q_auto/chzvbmewwamffyfhtnfy.jpg'
    },
    {
        image:'https://2.bp.blogspot.com/-6rMixsDoBZ8/W3EcqjYVchI/AAAAAAAAX78/WcGe8PlP25Q5VVIxz_j5NDKkJxX8gz_6QCLcBGAs/w1200-h630-p-k-no-nu/nike-kobe-ad-new-shoe-release-date-kobe-day-3.jpg'
    },
    {
        image:'https://i.pinimg.com/originals/02/3a/87/023a877e31bece11178bc786e058d49f.jpg'
    },
]